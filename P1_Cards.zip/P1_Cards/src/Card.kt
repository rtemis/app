import java.lang.NumberFormatException
import java.util.*
import kotlin.math.*
import java.io.*
import java.nio.file.Path
import java.time.*
import java.time.format.*
import javax.naming.spi.DirectoryManager


var cDate = 0
/**
 * @class Card
 * @author Leah Hadeed
 *
 * This class is the super class for cards. It contains all the pertinent information and the relevant functions for card manipulation.
 */
open class Card(var question: String, var answer: String, val id: String = UUID.randomUUID().toString(), val date: String = Date().toString()) {
    val rating = listOf<Int>(0,3,5)
//    val current = LocalDateTime.now()
//    val formatter = DateTimeFormatter.BASIC_ISO_DATE
//    val formatted = current.format(formatter)
    var quality = -1
    var repetitions = 0
    var interval = 1
    var nextPracticeDate = 0
    var easiness = 2.5
//    var currentDate = formatted.toInt()
    var currentDate = cDate

    /**
     * @function show
     * @author Leah Hadeed
     *
     * This function shows the card that is being used in testing. After showing the card, the relevant information is updated.
     */
    open fun show() {
        quality = -1
        println(question)
        println("Press enter to see the answer.")

        /* Waits for user to hit enter */
        readLine()
        println(answer)

        var x : Int? = null
        while (x == null && quality !in rating) {
            print("Rate question (0 hard, 3 moderate, 5 easy): ")
            x = readLine()!!.toIntOrNull()
            if (x != null)
                quality = x
        }

        /* Update the card */
        update()
    }

    /**
     * @function update
     * @author Leah Hadeed
     *
     * This function handles the updating of relevant card information based on given formulas.
     */
    fun update() {
        /* Easiness update */
        easiness = max(1.3, easiness + 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02))

        /* Repetitions update */
        repetitions = if (quality < 3) 0
        else repetitions + 1

        /* Interval update */
        interval = when (repetitions) {
            0, 1 -> 1
            2 -> 6
            else -> (interval * easiness).roundToInt()
        }

        /* Next practice date update */
        nextPracticeDate = currentDate + interval
    }

    /**
     * @function details
     * @author Leah Hadeed
     *
     * This function shows the pertinent details of a card.
     */
    fun details() {
        println("$question   $answer   eas = ${round(easiness)}   rep = ${repetitions}   int = ${interval}   next = ${nextPracticeDate}")
    }

    /* Comparion object for the creation of cards based on the choice between two types of card */
    companion object {
        /**
         * @Function Leer
         * @author Leah Hadeed
         *
         * This function allows the user to create a card based on their choices.
         */
        fun leer(): Card {
            var pregunta : String? = null
            var respuesta : String? = null
            var x = -1

            while (x !in 0..1)
            {
                println("Teclea el tipo 0 (Card) 1 (Cloze): ")
                x = readLine()?.toIntOrNull() ?: -1
            }

            println("Nueva tarjeta:")
            while (pregunta == null) {
                println("    Teclea la pregunta:")
                pregunta = readLine()
            }
            while (respuesta == null) {
                println("    Teclea la respuesta:")
                respuesta = readLine()
            }

            if (x == 0)
                return Card(pregunta.toString(), respuesta.toString())
            else
                return Cloze(pregunta.toString(), respuesta.toString())
        }
    }

}

/**
 * @class Cloze
 * @author Leah Hadeed
 *
 * This class is an extension of the Card class.
 *
 * This class allows the demonstration of cards that display a special question, whose answer replaces the
 * text between * *.
 *
 * Example:
 *      "I *como* chips" becomes "I eat chips"
 */
class Cloze(question: String, answer: String) : Card(question, answer) {
    override fun show() {
        quality = -1

        var change = ("\\*[a-zA-Z ]+\\*").toRegex()
        println(question)
        println("Press enter to see the answer.")

        /* Waits for user to hit enter */
        readLine()
        println(question.replace(change, answer))

        var x : Int? = null
        while (x == null && quality !in rating) {
            print("Rate question (0 hard, 3 moderate, 5 easy): ")
            x = readLine()!!.toIntOrNull()
            if (x != null)
                quality = x
        }
    }
}

/**
 * @Class Deck
 * @author: Leah Hadeed
 *
 * This class is in charge of the set of cards that will be used in testing.
 * This class comes with the functions necessary for the manipulation of the card data, such as reading and writing to files.
 */
class Deck() {
    var cards: MutableSet<Card> = mutableSetOf()

    /**
     * @Function: read
     * @author: Leah Hadeed
     *
     * This function parses the relevant card information from the text file located in the data directory.
     */
    fun read() {
        /* Variable declaration */
        val lineas : List<String> = File("data/cards.txt").readLines()
        var part : List<String>
        var type : Int
        var question : String
        var answer : String
        var repetitions : Int
        var interval : Int
        var nextPracticeDate : Int
        var easiness : Double
        var currentDate : Int

        /* For each line read, parse the relevant information and transform to proper data type */
        for (linea in lineas) {
            part = linea.split("|")
            type = part.get(0).toInt()
            question = part.get(1)
            answer = part.get(2)
            repetitions = part.get(3).toInt()
            interval = part.get(4).toInt()
            nextPracticeDate = part.get(5).toInt()
            easiness = part.get(6).toDouble()
            currentDate = part.get(7).toInt()

            /* Create a new card to hold the relevant data */
            var c : Card
            if (type == 0) {
                c = Card(question, answer)
                c.repetitions = repetitions
                c.interval = interval
                c.nextPracticeDate = nextPracticeDate
                c.easiness = easiness
                c.currentDate = currentDate
            } else {
                c = Cloze(question, answer)
                c.repetitions = repetitions
                c.interval = interval
                c.nextPracticeDate = nextPracticeDate
                c.easiness = easiness
                c.currentDate = currentDate
            }

            /* Add the card to the set */
            cards.add(c)
        }
    }

    /**
     * @Function: Write
     *
     * Writes the cards to the file.
     * This function is modifiable for different types of files.
     */
    fun write () {
        /* Saves details of the current deck in the file */
        cards.forEach{
            /* Test for card type */
            var type = if (it::class == Cloze::class) 1
            else 0

            /* Simple GUI*/
            it.details()

            /* Write to file */
            File("data/cards.txt").appendText( "$type|${it.question}|${it.answer }|${it.repetitions}|${it.interval}|${it.nextPracticeDate}|${round(it.easiness)}|${it.currentDate}\n")
        }
    }
}

/**
 * @Function: Timelapse
 * @author: Leah Hadeed
 *
 * Simulates the passage of time in a pratical setting, taking the current date and showing the relevant cards to practice
 *
 * @param Deck
 */
fun timelapse (deck: Deck) {
    /* Sets the simulation date to the current date */
//    val current = LocalDateTime.now()
//    val formatter = DateTimeFormatter.BASIC_ISO_DATE
//    val formatted = current.format(formatter)

    for (i in 1..20) {
        /* Temporary test GUI */
        println("Date: $cDate\n")

        /* Runs through the set of cards available in the current deck */
        for (c in deck.cards) {
            /* If the current date given for each card is before the current date, set the new date */
            if (c.currentDate < cDate) {
                c.currentDate = cDate

                /* If the next practice date is less than the current date, the card needs to be shown and updated */
                if (c.nextPracticeDate <= c.currentDate) {
                    c.show()
                    c.update()
                    /* Simple test GUI*/
                    c.details()
                }
            }
            println()
        }
        cDate += 1
    }
}

/* Main code */
fun main() {
    var deck = Deck()

    fun menu () {
        while (true) {
            var sel = -1
            var x: Int? = null
            while (x == null && sel !in 1..6) {
                println(
                    "1. Añadir tarjeta\n" +
                            "2. Presentar tarjetas\n" +
                            "3. Leer tarjetas de fichero\n" +
                            "4. Escribir tarjetas en fichero\n" +
                            "5. Simulación\n" +
                            "6. Salir\n" +
                            "Elige una opción:\n"
                )
                x = readLine()!!.toIntOrNull()
                if (x != null)
                    sel = x
            }

            when (sel) {
                1 -> deck.cards.add(Card.leer())
                2 -> { if (deck.cards.isEmpty()) println("Error. Try again.") else deck.cards.forEach {
                    if (it.nextPracticeDate <= cDate ) {
                        it.show()
                        it.update()
                    }
                }}
                3 -> { if (File("data/cards.txt").isFile ) deck.read() else println("Error. Try again.")}
                4 -> deck.write()
                5 -> timelapse(deck)
                6 -> {
                    if (!deck.cards.isEmpty()) {
                        File("data/cards.txt").delete()
                        File("data/cards.txt").createNewFile()
                        deck.write()
                    }
                    return
                }
                else -> println("Error. Try again.")
            }
        }
    }

    menu()

}
